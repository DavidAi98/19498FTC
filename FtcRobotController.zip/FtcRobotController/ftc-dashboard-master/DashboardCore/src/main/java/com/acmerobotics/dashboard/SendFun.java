package com.acmerobotics.dashboard;

import com.acmerobotics.dashboard.message.Message;

public interface SendFun {
    void send(Message message);
}
